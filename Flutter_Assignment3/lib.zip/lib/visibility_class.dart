import 'package:flutter/material.dart';

class VisibilityClass extends StatelessWidget{
  var isVisible;
  var name;
  var phone;
  VisibilityClass({required this.isVisible, required this.name,required this.phone});
  @override
  Widget build(BuildContext context) {
    return  Visibility(

      visible:isVisible,

      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),color: Colors.blue),

        margin: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
        padding: EdgeInsets.symmetric(vertical: 25,horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Name: $name ",style: TextStyle(fontSize: 15),),
            SizedBox(height: 8,),
            Text("Phone: $phone",style: TextStyle(fontSize: 15)),
          ],
        ),
      ),
    );
  }

}
