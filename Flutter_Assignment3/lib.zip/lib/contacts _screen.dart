import 'package:flutter/material.dart';
import 'package:untitled/visibility_class.dart';

class ContactsScreen extends StatefulWidget{
  @override
  State<ContactsScreen> createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  bool isVisible1=false;
  bool isVisible2= false;
  bool isVisible3=false;
  String name1 = '';
  String name2 = '';
  String name3 = '';
  String phone1 = '';
  String phone2 = '';
  String phone3 = '';

  @override
  Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: const Text('Contacts Screen'),
      centerTitle: true,
    ),
    body: SingleChildScrollView(

      child: Column(
         crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(

      margin: EdgeInsets.symmetric(horizontal: 10,vertical: 20),
          child: TextField(
            onChanged: (value){
              if(isVisible1==false && isVisible2 == false && isVisible3 == false ){
                setState(() {
                   name1 = value;
                });
              }
              if(isVisible1==true && isVisible2 == false  && isVisible3 == false ){
                setState(() {
                  name2 = value;
                });
              }
              if(isVisible1==true && isVisible2 == true && isVisible3 == false ){
                setState(() {
                  name3 = value;
                });
              }

            },
           decoration:
          InputDecoration(
            fillColor: Colors.white,
            filled: true,
            hintText: "Enter Your Name Here",
            suffixIcon:Icon(Icons.edit,color: Color(-14575885),),
            border:
            OutlineInputBorder(
              borderRadius: BorderRadius.circular(30),
              borderSide: BorderSide(color: Colors.blue,width: 2),

            )
        ),

      ),
      ),
          Container(

         margin: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
             child: TextField(
               onChanged: (value){
                 if(isVisible1==false && isVisible2 == false && isVisible3 == false ){
                   setState(() {
                     phone1= value;
                   });
                 }
                 if(isVisible1==true && isVisible2 == false  && isVisible3 == false ){
                   setState(() {
                     phone2 = value;
                   });
                 }
                 if(isVisible1==true && isVisible2 == true && isVisible3 == false ){
                   setState(() {
                     phone3 = value;
                   });
                 }
               },
             decoration:
             InputDecoration(
             fillColor: Colors.white,
             filled: true,
              hintText: "Enter Your Number Here",
              suffixIcon:Icon(Icons.call,color: Color(-14575885),),
              border:
               OutlineInputBorder(
               borderRadius: BorderRadius.circular(30),
               borderSide: BorderSide(color: Colors.blue,width: 2),

            )
        ),

      ),
      ),
          Row(
            children: [
              Expanded(
                child: Container(

                  margin: EdgeInsets.symmetric(horizontal: 5),
                  padding: EdgeInsets.symmetric(vertical: 15),
                  child: ElevatedButton(onPressed: (){
                    if(isVisible1==false && isVisible2==false &&isVisible3==false){

                      setState(() {
                        isVisible1=true;


                      });
                    }
                    else if(isVisible1==true && isVisible2==false &&isVisible3==false){
                      setState(() {
                       isVisible2=true;

                      });
                    }
                    else if(isVisible2==true &&isVisible3==false){
                      setState(() {
                        isVisible3=true;
                      });
                    }


                  }, child:Text('Add'),
                  style:ElevatedButton.styleFrom(primary: Colors.red,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)) )
                  ),
                ),
              ),
              Expanded(
                  child: Container(
                margin: EdgeInsets.symmetric(horizontal: 5),
                padding: EdgeInsets.symmetric(vertical: 15),
                child: ElevatedButton(onPressed: (){
                  if(isVisible1==true && isVisible2==true &&isVisible3==true){
                    setState(() {
                      isVisible3=false;

                    });
                  }
                  else if(isVisible1==true && isVisible2==true &&isVisible3==false){
                    setState(() {
                      isVisible2=false;

                    });
                  }
                  else if( isVisible1==true && isVisible2==false &&isVisible3==false){
                    setState(() {
                      isVisible1=false;
                    });
                  }


                }, child:Text('Delete'),
                    style:ElevatedButton.styleFrom(primary: Colors.blue,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)))
                ),
              ))
            ],
          ),
          VisibilityClass(isVisible: isVisible1, name: name1, phone: phone1),
          VisibilityClass(isVisible: isVisible2, name: name2, phone: phone2),
          VisibilityClass(isVisible: isVisible3, name: name3, phone: phone3),








        ],
      ),
    ),


  );
  }
}