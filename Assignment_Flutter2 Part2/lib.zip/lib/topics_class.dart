import 'package:flutter/material.dart';

class TopicClass extends StatelessWidget{
  String imagePath;
  String courseTopic;
  String navigator;
  TopicClass({required this.imagePath,required this.courseTopic,required this.navigator});
  @override
  Widget build(BuildContext context) {
    return Container(

        child: Column(
            children: [
              Container(
                  padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                  child: Image.asset(imagePath)),


              Container(
                       decoration:BoxDecoration(
                         shape: BoxShape.rectangle ,
                       ),
                  padding: EdgeInsets.symmetric(vertical: 1,),
                  margin: EdgeInsets.symmetric(vertical: 0,horizontal: 2) ,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(minimumSize:Size(480, 50)),
                  onPressed: () {
                  Navigator.pushNamed(context,navigator);
                },
                  child: Text(courseTopic),)),

            ]


        )  );
  }
}