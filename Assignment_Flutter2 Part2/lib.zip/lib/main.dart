import 'package:flutter/material.dart';
import 'package:untitled/android_screen.dart';
import 'package:untitled/full_stack_screen.dart';
import 'package:untitled/home_screen.dart';
import 'package:untitled/ios_screen.dart';

void main(){

  runApp(App());

}

class App extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: HomeScreen.routName,
      routes: {
        HomeScreen.routName:(context) => HomeScreen(),
        AndroidCourse.routName:(context) => AndroidCourse(),
        IosCourse.routName:(context) => IosCourse(),
        FullStackCourse.routName:(context) => FullStackCourse()


      },


    );
  }

}