import 'package:flutter/material.dart';

class FullStackCourse extends StatelessWidget{
  static const String routName = 'FullStackScreen';
  @override
  Widget build(BuildContext context) {
   return Scaffold(
     appBar: AppBar(
       automaticallyImplyLeading: false,
       title: Text('RoutAppOne'),
       backgroundColor: Color(-16769149),

     ),
     body: Container(
       decoration: const BoxDecoration(image:
       DecorationImage(image: AssetImage('assets/images/Bg.jpg',)
         ,fit: BoxFit.fill,),),
       child: SingleChildScrollView(
         child: Column(
           children: [

             Container(
                 padding: EdgeInsets.symmetric(vertical: 20,horizontal: 10),
                 child: Image.asset('assets/images/fullStack.jpeg')
             ),
             Container(
               padding: EdgeInsets.symmetric(horizontal: 15),
               child: const Text(''' 
•HTML	
•HTML 5 
•CSS
•CSS3
•SASS
•Bootstrap 4
•JavaScript
•Regular expressions
•ECMAScript 6
•JQuery
•angular 7
•fabric.js
•AJAX
•JSON
•Hosting and domains
•Freelancing tips and tricks
•PHP
•MYSQL
•MYSQL advanced queries and triggers
•OOP 
•Design Patterns
•MVC
•laravel 
•build Api , Api authentication
•connect wordpress with laravel
•build wordpress web service 
•agile
•Scrum
•Software development process
''',style:TextStyle(color: Colors.white,fontSize: 20),),
             )
           ],
         ),
       ),
     ),

   );
  }

}