import 'package:flutter/material.dart';
import 'package:untitled/android_screen.dart';
import 'package:untitled/full_stack_screen.dart';
import 'package:untitled/ios_screen.dart';
import 'package:untitled/topics_class.dart';

class HomeScreen extends StatelessWidget{
  static const String routName = "HOME";
  @override
  Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      backgroundColor: Color(-16769149),
      title: Text('RouteAppOne'),
    ),
    body: SingleChildScrollView(
      child: Column(
        children: [
          TopicClass(imagePath:'assets/images/Android.jpeg', courseTopic: 'ANDROID COURSE',navigator: AndroidCourse.routName,),
          TopicClass(imagePath:'assets/images/IOS.jpeg', courseTopic: 'IOS COURSE',navigator: IosCourse.routName,),
          TopicClass(imagePath:'assets/images/fullStack.jpeg', courseTopic: 'FULL STACK COURSE',navigator: FullStackCourse.routName,),
        ],
      )
    

      ));
  }

}